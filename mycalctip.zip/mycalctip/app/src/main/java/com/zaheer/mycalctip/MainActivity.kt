package com.zaheer.mycalctip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var Number1EditText:EditText
    private lateinit var Number2EditText:EditText
    private lateinit var AdditionButton:Button
    private lateinit var SubtractionButton:Button
    private lateinit var MultiplicationButton:Button
    private lateinit var DivisionButton:Button
    private lateinit var ResultTextView:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        Number1EditText = findViewById(R.id.Number1EditText)
        Number2EditText = findViewById(R.id.Number2EditText)
        AdditionButton = findViewById(R.id.AdditionButton)
        SubtractionButton = findViewById(R.id.SubtractionButton)
        MultiplicationButton = findViewById(R.id.MultiplicationButton)
        DivisionButton = findViewById(R.id.DivisionButton)
        ResultTextView = findViewById(R.id.ResultTextView)

        //AdditionButton.setOnClickListener {performOperation("+")}
        //SubtractionButton.setOnClickListener {performOperation("-")}
        //MultiplicationButton.setOnClickListener {performOperation("*")}
        //DivisionButton.setOnClickListener {performOperation("/")}

        MultiplicationButton.setOnClickListener {
            val Number1 = Number1EditText.text.toString().toInt()
            val Number2 = Number2EditText.text.toString().toInt()

            val result = Number1 * Number2

            val Display = "$Number1 * $Number2 =$result"
            ResultTextView.text = Display
        }
        DivisionButton.setOnClickListener {
            val Number1 = Number1EditText.text.toString().toInt()
            val Number2 = Number2EditText.text.toString().toInt()

            val result = Number1 / Number2

            val Display = "$Number1 / $Number2 =$result"
            ResultTextView.text = Display
        }

        AdditionButton.setOnClickListener {
            val Number1 = Number1EditText.text.toString().toInt()
            val Number2 = Number2EditText.text.toString().toInt()

            val result = Number1 + Number2

            val Display = "$Number1 + $Number2 =$result"
            ResultTextView.text = Display
        }

        SubtractionButton.setOnClickListener {
            val Number1 = Number1EditText.text.toString().toInt()
            val Number2 = Number2EditText.text.toString().toInt()

            val result = Number1 - Number2

            val Display = "$Number1 - $Number2 =$result"
            ResultTextView.text = Display
        }

